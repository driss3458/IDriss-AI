'use client';
import { useState } from "react";

export default function Home() {
  const [messages, setMessages] = useState([
    { sender: "bot", text: "Hello! مرحبًا! I am Idriss AI. How can I help you?" },
  ]);
  const [input, setInput] = useState("");

  const sendMessage = async () => {
    if (!input.trim()) return;

    const updated = [...messages, { sender: "user", text: input }];
    setMessages(updated);
    setInput("");

    const lower = input.toLowerCase();
    let reply = "";

    if (lower.includes("who made you") || lower.includes("من برمجك") || lower.includes("من صنعك")) {
      reply = "تمت برمجتي بواسطة IDriss Laadim 💡";
    } else {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: input })
      });
      const data = await res.json();
      reply = data.response;
    }

    setMessages([...updated, { sender: "bot", text: reply }]);
  };

  return (
    <main className="max-w-2xl mx-auto mt-10 p-4">
      <h1 className="text-2xl font-bold text-center mb-4">Idriss AI 🤖</h1>
      <div className="h-96 overflow-y-auto bg-gray-100 rounded p-4 mb-4">
        {messages.map((msg, i) => (
          <div key={i} className={`mb-2 ${msg.sender === 'user' ? 'text-right' : 'text-left'}`}>
            <span className={`inline-block px-3 py-2 rounded-lg ${msg.sender === 'user' ? 'bg-blue-200' : 'bg-green-200'}`}>
              {msg.text}
            </span>
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        <input
          className="flex-1 border border-gray-300 p-2 rounded"
          placeholder="Ask me in English or Arabic..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
        />
        <button onClick={sendMessage} className="bg-blue-500 text-white px-4 py-2 rounded">Send</button>
      </div>
    </main>
  );
}