# Idriss AI

مساعد ذكي يعمل باستخدام OpenAI API، يدعم اللغة العربية والإنجليزية.
تمت برمجته بواسطة IDriss Laadim 💡

## الخطوات للنشر على Vercel

1. أنشئ حسابًا على [Vercel](https://vercel.com/)
2. حمّل هذا المشروع إلى GitHub
3. اربطه مع Vercel
4. في إعدادات المشروع على Vercel، أضف متغير بيئة:
   - `OPENAI_API_KEY` = مفتاحك من [https://platform.openai.com/account/api-keys](https://platform.openai.com/account/api-keys)
5. اضغط Deploy 🚀